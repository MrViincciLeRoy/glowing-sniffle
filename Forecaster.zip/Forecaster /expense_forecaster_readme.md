# Expense Forecaster Module

## Overview

The **Expense Forecaster** is a comprehensive Odoo module that provides advanced expense forecasting, analytics, and cashflow projection capabilities for businesses. It integrates seamlessly with the GMailer and ERPNext Bridge modules to provide actionable insights from your bank transactions.

## Key Features

### 🔮 Intelligent Forecasting
- **Multiple Forecasting Methods:**
  - Historical Average: Simple average of past transactions
  - Trend Analysis: Identifies increasing/decreasing patterns
  - Recurring Pattern Detection: Spots subscriptions and regular payments
  - Seasonal Adjustment: Accounts for monthly variations
- **Automatic Method Selection:** System chooses the best forecasting method based on your data
- **Confidence Scoring:** Each forecast includes a confidence percentage
- **Support for Categorized & Uncategorized Transactions**

### 📊 Expense Analytics
- **Comprehensive Analysis:**
  - Total expenses and income tracking
  - Net cashflow calculations
  - Average daily expense
  - Transaction categorization rates
  - Top spending categories
  - Trend identification (increasing/stable/decreasing)
- **Anomaly Detection:** Identifies unusual transactions
- **Period Comparisons:** Week, month, quarter, and year views

### 💰 Cashflow Projections
- **Future Cash Position:** Project your bank balance for upcoming months
- **Risk Assessment:** 
  - Healthy (balance > 1.5x minimum)
  - Warning (balance > minimum)
  - Critical (balance < minimum)
- **Confidence Levels:** Track projection accuracy
- **Visual Alerts:** Clear indicators for potential cashflow issues

### 🔍 Transaction Insights
- **Pattern Recognition:**
  - Recurring transactions
  - One-time payments
  - Occasional expenses
- **Risk Scoring:** High/Medium/Low risk classification
- **Similar Transaction Finder:** Group related transactions
- **Spending Pattern Analysis**

## Installation

### Prerequisites
- Odoo 17.0
- `GMailer` module installed
- `gmail_erpnext_bridge` module installed
- Python packages: `python-dateutil`

### Installation Steps

1. **Copy Module to Addons Directory:**
```bash
cp -r expense_forecaster /path/to/odoo/custom-addons/
```

2. **Update Module List:**
- Go to Apps > Update Apps List
- Search for "Expense Forecaster"
- Click Install

3. **Initial Configuration:**
- Navigate to Expense Forecaster > Configuration > Forecaster Configuration
- Create a new forecaster with your preferred settings:
  - Forecast Period: 3-6 months recommended
  - Historical Period: 6-12 months recommended
  - Minimum Transactions: 3 minimum

## Usage Guide

### Step 1: Generate Initial Forecasts

**Method 1: Manual Generation**
1. Go to **Expense Forecaster > Configuration**
2. Open your forecaster record
3. Click **"🔮 Generate Forecasts"**

**Method 2: Quick Action**
1. Go to **Expense Forecaster > Quick Actions > Generate Forecasts**

### Step 2: Review Forecasts

1. Navigate to **Expense Forecaster > Forecasts**
2. Review the generated forecasts
3. Check confidence scores and methods used
4. Filter by:
   - Date range
   - Category
   - Forecast type (expense/income)
   - Confidence level

### Step 3: Create Cashflow Projections

1. Go to **Expense Forecaster > Cashflow Projections**
2. Click **"Quick Actions > Generate Projections"**
3. Review projected balances
4. Pay attention to status indicators:
   - 🟢 Healthy: You're good!
   - 🟡 Warning: Monitor closely
   - 🔴 Critical: Take action

### Step 4: Analyze Spending Patterns

1. Navigate to **Expense Forecaster > Analytics**
2. Click **"Generate Insights"** or use Quick Actions
3. Select period (week/month/quarter/year)
4. Review the comprehensive analysis:
   - Total expenses vs income
   - Categorization rate
   - Top spending categories
   - Trend analysis
   - Unusual transactions

### Step 5: Monitor Transaction Insights

1. Go to **Statement Importer > Transactions**
2. Use filters to find:
   - Recurring transactions
   - Unusual amounts
   - High-risk transactions
   - Uncategorized items
3. Click **"View Similar"** to group related transactions
4. Review spending patterns

## Understanding the Data

### Forecasting Methods Explained

**Historical Average (65% confidence)**
- Simple average of past transactions
- Best for stable, predictable expenses
- Example: Regular office supplies

**Recurring Pattern (85% confidence)**
- Detects regular payments with consistent amounts
- Best for subscriptions, rent, salaries
- Example: R499 monthly Netflix subscription

**Trend Analysis (75% confidence)**
- Identifies increasing or decreasing patterns
- Best for growing businesses or changing habits
- Example: Gradually increasing fuel costs

**Seasonal Adjustment (70% confidence)**
- Accounts for monthly variations
- Best for businesses with seasonal patterns
- Example: Higher expenses in December

### Risk Levels

**Low Risk:**
- Categorized transaction
- Normal amount for the category
- Recognized pattern

**Medium Risk:**
- Either unusual amount OR uncategorized
- Needs attention but not urgent

**High Risk:**
- Both unusual amount AND uncategorized
- Requires immediate review
- Potential fraud or error

### Spending Patterns

**Regular:**
- Occurs monthly or more frequently
- Example: Groceries, fuel, utilities

**Occasional:**
- Occurs quarterly or a few times per year
- Example: Quarterly software licenses

**One-time:**
- Rare or unique transaction
- Example: Equipment purchase

## Automation

The module includes automated cron jobs:

### Daily: Generate Forecasts
- Runs every day at midnight
- Updates all forecasts for forecasters with "Auto-update" enabled
- Keeps predictions fresh

### Weekly: Generate Projections
- Runs every Sunday
- Creates cashflow projections for next 6 months
- Helps with cash management

### Monthly: Analytics Report
- Runs on 1st of each month
- Creates comprehensive analytics for previous month
- Great for monthly reviews

**To disable automation:**
1. Go to Settings > Technical > Automation > Scheduled Actions
2. Find the relevant cron job
3. Uncheck "Active"

## Tips for Best Results

### 1. Categorize Your Transactions
- Categorized transactions produce better forecasts
- Use the auto-categorization feature
- Review and adjust categories regularly

### 2. Maintain Historical Data
- Keep at least 6 months of transaction history
- More data = better predictions
- Don't delete old transactions

### 3. Review Forecasts Regularly
- Check forecast accuracy monthly
- Adjust your minimum transaction requirements if needed
- Update category keywords for better auto-categorization

### 4. Set Appropriate Minimums
- Configure your minimum cashflow balance
- Adjust based on your business needs
- Consider seasonal variations

### 5. Act on Insights
- Review unusual transactions promptly
- Investigate high-risk items
- Categorize uncategorized transactions
- Monitor your cashflow projections

## Integration with Other Modules

### GMailer Module
- Automatically receives bank transactions
- Provides transaction data for forecasting
- No configuration needed

### ERPNext Bridge
- Uses transaction categories
- Syncs data to ERPNext accounting
- Maintains consistency across systems

## Dashboard Overview

The main dashboard provides:
- **Graph View:** Visual representation of forecasts
- **Pivot View:** Detailed analysis by category and month
- **Quick Filters:** Easy access to relevant data
- **Status Indicators:** Color-coded for quick assessment

## Troubleshooting

### Problem: No Forecasts Generated

**Solutions:**
1. Check if you have enough historical transactions (default: 3 minimum)
2. Verify date range in forecaster configuration
3. Ensure transactions are dated correctly
4. Lower the "Min Transactions Required" setting

### Problem: Low Confidence Scores

**Solutions:**
1. Increase historical period (use 12 months instead of 6)
2. Ensure consistent transaction patterns
3. Categorize more transactions
4. Wait for more data to accumulate

### Problem: Inaccurate Projections

**Solutions:**
1. Update your opening balance
2. Review and adjust forecasts manually
3. Mark unusual transactions appropriately
4. Increase minimum transaction requirements

### Problem: Cashflow Warnings

**Actions:**
1. Review upcoming expenses
2. Check for large unusual transactions
3. Verify income forecasts
4. Adjust spending if needed
5. Consider credit facilities

## API / Programmatic Access

### Generate Forecasts Programmatically

```python
# Get or create forecaster
forecaster = env['expense.forecaster'].search([], limit=1)
if not forecaster:
    forecaster = env['expense.forecaster'].create({
        'name': 'My Forecaster',
        'forecast_period_months': 3,
        'historical_period_months': 6,
    })

# Generate forecasts
forecaster.generate_forecasts()
```

### Get Forecast Summary

```python
forecaster = env['expense.forecaster'].search([], limit=1)
summary = forecaster.get_forecast_summary(months=3)

print(f"Total Expenses: {summary['total_expenses']}")
print(f"Total Income: {summary['total_income']}")
print(f"Net Forecast: {summary['net_forecast']}")
```

### Get Spending Insights

```python
insights = env['bank.transaction'].get_spending_insights(period='month')

print(f"Total Spent: {insights['total_spent']}")
print(f"Recurring Transactions: {insights['recurring_count']}")
print(f"Unusual Transactions: {insights['unusual_count']}")
```

## Support

For issues, questions, or feature requests:
- Check the Odoo logs for error messages
- Review transaction data quality
- Verify module dependencies are installed
- Check cron job status

## Roadmap

Planned future features:
- Machine learning-based forecasting
- Budget comparison tools
- Multi-currency support
- Custom alert thresholds
- Email notifications for critical cashflow
- Integration with more banking APIs
- Mobile dashboard
- Export to PDF/Excel

## License

LGPL-3

## Credits

Developed for integration with:
- GMailer (bank statement importer)
- ERPNext Bridge (accounting integration)

---

**Version:** 1.0  
**Last Updated:** 2025-01-27  
**Odoo Version:** 17.0